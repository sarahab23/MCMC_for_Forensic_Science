largest <- function(x){
  ans1 <- larg(x)
  ans1
}
smallest <- function(x){
  ans2 <- small(x)
  ans2
}